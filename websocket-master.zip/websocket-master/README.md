<p align="center">
<img src="https://readme-typing-svg.herokuapp.com?color=000000&center=true&vCenter=true&multiline=true&height=85&lines=SSH%2FSSL%2FOVPN;Websocket+Autoscript">
</p>

```
rm -f install* && wget -q https://raw.githubusercontent.com/excelsiorcode/websocket/master/install && chmod +x install && ./install
```
